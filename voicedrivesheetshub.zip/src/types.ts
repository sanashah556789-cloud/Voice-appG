export interface UserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
}

export interface VoiceMessageRecord {
  id: string;
  timestamp: string; // ISO string
  formattedTime: string;
  type: 'voice' | 'text';
  sender: 'user' | 'assistant';
  content: string; // transcript or text message
  audioBlob?: Blob;
  audioUrl?: string; // local object URL or remote URL
  audioDuration?: number; // duration in seconds
  driveFileId?: string;
  driveFileName?: string;
  driveViewLink?: string;
  driveDownloadLink?: string;
  sheetRowIndex?: number;
  syncStatus: 'pending' | 'uploading_drive' | 'updating_sheet' | 'synced' | 'error';
  errorMessage?: string;
}

export interface WorkspaceFolder {
  id: string;
  name: string;
  webViewLink?: string;
}

export interface WorkspaceSpreadsheet {
  id: string;
  title: string;
  webViewLink?: string;
  sheetName: string;
}

export interface SheetRowData {
  id: string;
  dateTime: string;
  type: string;
  sender: string;
  messageOrTranscript: string;
  driveLink: string;
  durationOrInfo: string;
  status: string;
}

export interface DriveFileInfo {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime: string;
  webViewLink: string;
  webContentLink?: string;
}
