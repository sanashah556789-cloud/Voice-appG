import React, { useState, useRef } from 'react';
import { VoiceMessageRecord } from '../types';
import {
  Send,
  Play,
  Pause,
  ExternalLink,
  Copy,
  Check,
  FileSpreadsheet,
  HardDrive,
  Bot,
  User,
  Mic,
  Sparkles,
} from 'lucide-react';

interface ChatTimelineProps {
  messages: VoiceMessageRecord[];
  onSendTextMessage: (text: string, enableAiReply: boolean) => Promise<void>;
  isProcessing: boolean;
  driveFolderName: string;
  sheetTitle: string;
}

export const ChatTimeline: React.FC<ChatTimelineProps> = ({
  messages,
  onSendTextMessage,
  isProcessing,
  driveFolderName,
  sheetTitle,
}) => {
  const [inputText, setInputText] = useState('');
  const [enableAiReply, setEnableAiReply] = useState(true);
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const audioRefs = useRef<{ [key: string]: HTMLAudioElement }>({});

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || isProcessing) return;
    const textToSend = inputText.trim();
    setInputText('');
    await onSendTextMessage(textToSend, enableAiReply);
  };

  const togglePlayAudio = (id: string) => {
    const audio = audioRefs.current[id];
    if (!audio) return;

    if (playingMessageId === id) {
      audio.pause();
      setPlayingMessageId(null);
    } else {
      // Pause any currently playing
      if (playingMessageId && audioRefs.current[playingMessageId]) {
        audioRefs.current[playingMessageId].pause();
      }
      audio.play();
      setPlayingMessageId(id);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex flex-col h-[650px] bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
      {/* Header */}
      <div className="px-6 py-3.5 border-b border-slate-200 bg-slate-50/70 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
            <span>Voice & Chat Stream</span>
            <span className="text-xs text-slate-500 font-normal">
              · {messages.length} {messages.length === 1 ? 'record' : 'records'}
            </span>
          </h3>
          <p className="text-xs text-slate-500">
            Messages & voice notes logged to <span className="font-medium text-slate-700">{sheetTitle}</span>
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 select-none">
            <input
              type="checkbox"
              checked={enableAiReply}
              onChange={(e) => setEnableAiReply(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              AI Assistant Replies
            </span>
          </label>
        </div>
      </div>

      {/* Messages Timeline Scroll Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
              <Mic className="w-6 h-6" />
            </div>
            <p className="text-sm font-medium text-slate-700">No voice or chat messages yet</p>
            <p className="text-xs text-slate-500 max-w-sm mt-1 leading-relaxed">
              Record a voice note above or type a message below. Recordings are stored in Google
              Drive ({driveFolderName}) and automatically saved as spreadsheet rows with direct links!
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const isVoice = msg.type === 'voice';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-2xl ${
                  isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Sender Avatar */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-semibold ${
                    isUser
                      ? 'bg-blue-600 text-white'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`flex flex-col rounded-xl p-4 text-sm transition-all border ${
                    isUser
                      ? 'bg-blue-50/70 text-slate-900 border-blue-100'
                      : 'bg-white text-slate-900 border-slate-200'
                  }`}
                >
                  {/* Bubble Header */}
                  <div className="flex items-center justify-between gap-4 text-xs text-slate-500 mb-1.5 pb-1 border-b border-slate-200/50">
                    <span className="font-medium text-slate-700">
                      {isUser ? 'You' : 'AI Assistant'}
                    </span>
                    <span className="font-mono text-[11px]">{msg.formattedTime}</span>
                  </div>

                  {/* Audio Player if Voice Note */}
                  {isVoice && msg.audioUrl && (
                    <div className="my-2 p-3 bg-white rounded-lg border border-slate-200 shadow-2xs">
                      <audio
                        ref={(el) => {
                          if (el) audioRefs.current[msg.id] = el;
                        }}
                        src={msg.audioUrl}
                        onEnded={() => setPlayingMessageId(null)}
                      />

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => togglePlayAudio(msg.id)}
                          className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center hover:bg-emerald-700 transition-colors shrink-0"
                          title={playingMessageId === msg.id ? 'Pause voice' : 'Play voice'}
                        >
                          {playingMessageId === msg.id ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4 ml-0.5" />
                          )}
                        </button>

                        <div className="flex-1">
                          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                            <span className="flex items-center gap-1 font-medium text-slate-700">
                              <Mic className="w-3.5 h-3.5 text-emerald-600" />
                              Voice Recording
                            </span>
                            <span className="font-mono text-[11px]">
                              {formatDuration(msg.audioDuration)}
                            </span>
                          </div>
                          <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full bg-emerald-500 transition-all ${
                                playingMessageId === msg.id ? 'animate-pulse' : ''
                              }`}
                              style={{ width: playingMessageId === msg.id ? '100%' : '0%' }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Message Content / Transcript */}
                  {msg.content && (
                    <div className="text-slate-800 leading-relaxed break-words whitespace-pre-wrap mt-1">
                      {msg.content}
                    </div>
                  )}

                  {/* Footer / Drive & Sheets Sync Status */}
                  <div className="mt-3 pt-2 border-t border-slate-200/60 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                    <div className="flex items-center gap-2">
                      {msg.driveViewLink ? (
                        <a
                          href={msg.driveViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-medium hover:underline"
                        >
                          <HardDrive className="w-3.5 h-3.5" />
                          <span>Google Drive Link</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      ) : msg.syncStatus === 'uploading_drive' ? (
                        <span className="flex items-center gap-1 text-amber-600">
                          <div className="w-2.5 h-2.5 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />
                          Uploading to Drive...
                        </span>
                      ) : null}

                      {msg.syncStatus === 'synced' && (
                        <span className="flex items-center gap-1 text-slate-600">
                          <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
                          <span>Logged to Sheet</span>
                        </span>
                      )}
                    </div>

                    {msg.content && (
                      <button
                        onClick={() => copyToClipboard(msg.content, msg.id)}
                        className="text-slate-400 hover:text-slate-600 p-0.5 rounded transition-colors"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input Message Area */}
      <form onSubmit={handleSend} className="p-4 bg-slate-50 border-t border-slate-200">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a message or note to log to Sheet... (اردو یا انگریزی میں میسج لکھیں)"
            disabled={isProcessing}
            className="flex-1 bg-white border border-slate-300 rounded-lg px-4 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />

          <button
            type="submit"
            disabled={!inputText.trim() || isProcessing}
            className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-lg transition-colors flex items-center justify-center shrink-0"
            title="Send and log to Sheet"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
