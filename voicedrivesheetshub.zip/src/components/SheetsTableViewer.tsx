import React, { useState } from 'react';
import { SheetRowData, WorkspaceSpreadsheet } from '../types';
import {
  FileSpreadsheet,
  ExternalLink,
  RefreshCw,
  Search,
  Trash2,
  HardDrive,
  Mic,
  MessageSquare,
} from 'lucide-react';
import { ConfirmationModal } from './ConfirmationModal';

interface SheetsTableViewerProps {
  spreadsheet: WorkspaceSpreadsheet | null;
  rows: SheetRowData[];
  isLoading: boolean;
  onRefresh: () => Promise<void>;
  onClearSheet: () => Promise<void>;
  isAuthenticated: boolean;
}

export const SheetsTableViewer: React.FC<SheetsTableViewerProps> = ({
  spreadsheet,
  rows,
  isLoading,
  onRefresh,
  onClearSheet,
  isAuthenticated,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  const filteredRows = rows.filter((r) => {
    const q = searchTerm.toLowerCase();
    return (
      r.messageOrTranscript.toLowerCase().includes(q) ||
      r.sender.toLowerCase().includes(q) ||
      r.type.toLowerCase().includes(q) ||
      r.dateTime.toLowerCase().includes(q)
    );
  });

  const handleConfirmClear = async () => {
    setIsClearing(true);
    try {
      await onClearSheet();
    } finally {
      setIsClearing(false);
      setIsClearModalOpen(false);
    }
  };

  // Helper to extract URL from formula or raw text
  const extractUrl = (text: string) => {
    if (!text) return null;
    const match = text.match(/https:\/\/[^\s",)]+/);
    return match ? match[0] : null;
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
      {/* Table Header Controls */}
      <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/70">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <h3 className="text-base font-semibold text-slate-900">
              {spreadsheet?.title || 'Google Sheets Master Log'}
            </h3>
            {spreadsheet?.webViewLink && (
              <a
                href={spreadsheet.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline ml-2"
              >
                <span>Open in Google Sheets</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time spreadsheet synchronization: Tab{' '}
            <span className="font-mono text-slate-700 font-medium">
              "{spreadsheet?.sheetName || 'Voice & Chat Logs'}"
            </span>
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search sheet rows..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 placeholder-slate-400 w-44"
            />
          </div>

          <button
            onClick={onRefresh}
            disabled={isLoading || !isAuthenticated}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
            title="Refresh rows from Google Sheet"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {rows.length > 0 && (
            <button
              onClick={() => setIsClearModalOpen(true)}
              disabled={isLoading || !isAuthenticated}
              className="px-3 py-1.5 text-xs font-medium text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg border border-red-200 transition-colors flex items-center gap-1.5 whitespace-nowrap"
              title="Clear logged sheet rows"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Rows</span>
            </button>
          )}
        </div>
      </div>

      {/* Grid Container */}
      <div className="overflow-x-auto min-h-[300px]">
        {!isAuthenticated ? (
          <div className="p-12 text-center text-slate-500">
            <FileSpreadsheet className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-700">Google Account Not Connected</p>
            <p className="text-xs text-slate-500 mt-1">
              Sign in with your Google account to view and synchronize live Google Sheets records.
            </p>
          </div>
        ) : filteredRows.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <FileSpreadsheet className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-700">No rows in this spreadsheet yet</p>
            <p className="text-xs text-slate-500 mt-1">
              Record a voice note or send a chat message to start logging entries directly into your
              Google Sheet!
            </p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-2.5 px-4"># ID</th>
                <th className="py-2.5 px-4">Date & Time</th>
                <th className="py-2.5 px-4">Type</th>
                <th className="py-2.5 px-4">Sender</th>
                <th className="py-2.5 px-4 max-w-xs">Message / Transcript</th>
                <th className="py-2.5 px-4">Drive Audio Link</th>
                <th className="py-2.5 px-4">Duration</th>
                <th className="py-2.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredRows.map((row, index) => {
                const driveUrl = extractUrl(row.driveLink);
                const isVoice = row.type.toLowerCase().includes('voice');

                return (
                  <tr key={row.id || index} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500">{row.id}</td>
                    <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{row.dateTime}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 font-medium text-slate-700">
                        {isVoice ? (
                          <Mic className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <MessageSquare className="w-3 h-3 text-blue-600" />
                        )}
                        {row.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800 whitespace-nowrap">
                      {row.sender}
                    </td>
                    <td className="py-3 px-4 max-w-sm text-slate-700 break-words leading-relaxed">
                      {row.messageOrTranscript || '—'}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {driveUrl ? (
                        <a
                          href={driveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-medium hover:underline text-[11px]"
                        >
                          <HardDrive className="w-3 h-3" />
                          <span>Open in Drive</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      ) : (
                        <span className="text-slate-400">N/A</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                      {row.durationOrInfo || '—'}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 text-slate-600 font-medium text-[11px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        {row.status || 'Synced'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirmation Dialog for Clearing Sheet (Mandatory destructive operation confirmation) */}
      <ConfirmationModal
        isOpen={isClearModalOpen}
        title="Clear Google Sheet Rows?"
        description={`Are you sure you want to clear all data rows from "${spreadsheet?.title || 'Voice & Chat Master Log'}"? This will delete all logged records from the spreadsheet while preserving the column headers. This action cannot be undone.`}
        confirmLabel="Clear Rows"
        isDestructive={true}
        isLoading={isClearing}
        onConfirm={handleConfirmClear}
        onCancel={() => setIsClearModalOpen(false)}
      />
    </div>
  );
};
