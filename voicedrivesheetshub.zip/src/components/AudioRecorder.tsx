import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Pause,
  Play,
  RotateCcw,
  UploadCloud,
  FileSpreadsheet,
  CheckCircle,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface AudioRecorderProps {
  onSaveVoiceNote: (audioBlob: Blob, duration: number, autoTranscribe: boolean) => Promise<void>;
  isProcessing: boolean;
  statusText?: string;
  driveConnected: boolean;
  sheetsConnected: boolean;
}

export const AudioRecorder: React.FC<AudioRecorderProps> = ({
  onSaveVoiceNote,
  isProcessing,
  statusText,
  driveConnected,
  sheetsConnected,
}) => {
  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'paused' | 'review'>(
    'idle'
  );
  const [seconds, setSeconds] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [autoTranscribe, setAutoTranscribe] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Playback preview state
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(0);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Audio visualizer refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      stopVisualizer();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    };
  }, []);

  const startVisualizer = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;

      const source = ctx.createMediaStreamSource(stream);
      source.connect(analyser);

      const canvas = canvasRef.current;
      if (!canvas) return;
      const canvasCtx = canvas.getContext('2d');
      if (!canvasCtx) return;

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const draw = () => {
        animationFrameRef.current = requestAnimationFrame(draw);
        analyser.getByteFrequencyData(dataArray);

        canvasCtx.clearRect(0, 0, canvas.width, canvas.height);

        const barWidth = (canvas.width / bufferLength) * 1.5;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = (dataArray[i] / 255) * (canvas.height * 0.85);

          // Google Drive emerald green gradient
          canvasCtx.fillStyle = '#0F9D58';
          canvasCtx.beginPath();
          canvasCtx.roundRect(
            x,
            canvas.height - barHeight - 4,
            Math.max(barWidth - 2, 2),
            barHeight + 4,
            2
          );
          canvasCtx.fill();

          x += barWidth;
        }
      };

      draw();
    } catch (e) {
      console.warn('Audio visualizer not supported or failed to start:', e);
    }
  };

  const stopVisualizer = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
  };

  const startRecording = async () => {
    setErrorMsg(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      let mimeType = 'audio/webm';
      if (!MediaRecorder.isTypeSupported('audio/webm')) {
        mimeType = 'audio/mp4';
      }

      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const fullBlob = new Blob(audioChunksRef.current, { type: mimeType });
        setAudioBlob(fullBlob);
        const url = URL.createObjectURL(fullBlob);
        setAudioUrl(url);
        stopVisualizer();

        // Stop stream tracks
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }
      };

      recorder.start(100);
      setRecordingState('recording');
      setSeconds(0);
      startVisualizer(stream);

      timerIntervalRef.current = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone access denied:', err);
      setErrorMsg(
        'Microphone access is required to record voice notes. Please permit microphone access in your browser settings.'
      );
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && recordingState === 'recording') {
      mediaRecorderRef.current.pause();
      setRecordingState('paused');
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && recordingState === 'paused') {
      mediaRecorderRef.current.resume();
      setRecordingState('recording');
      timerIntervalRef.current = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
  };

  const stopAndReview = () => {
    if (mediaRecorderRef.current && (recordingState === 'recording' || recordingState === 'paused')) {
      mediaRecorderRef.current.stop();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      setRecordingState('review');
    }
  };

  const discardRecording = () => {
    if (mediaRecorderRef.current && recordingState !== 'idle') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    stopVisualizer();
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (audioUrl) URL.revokeObjectURL(audioUrl);

    setRecordingState('idle');
    setSeconds(0);
    setAudioBlob(null);
    setAudioUrl(null);
    setIsPlayingPreview(false);
  };

  const handleSave = async () => {
    if (!audioBlob) return;
    await onSaveVoiceNote(audioBlob, seconds, autoTranscribe);
    discardRecording();
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const togglePlaybackPreview = () => {
    if (!audioPlayerRef.current) return;
    if (isPlayingPreview) {
      audioPlayerRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      audioPlayerRef.current.play();
      setIsPlayingPreview(true);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <Mic className="w-4 h-4 text-emerald-600" />
            Voice Studio (وائس ریکارڈر)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Record audio notes to upload to Google Drive and append as row links in Google Sheets.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs text-slate-600">
          <div className="flex items-center gap-1.5">
            <div
              className={`w-2 h-2 rounded-full ${
                driveConnected ? 'bg-emerald-500' : 'bg-slate-300'
              }`}
            />
            <span>Drive Folder: {driveConnected ? 'Ready' : 'Connect Account'}</span>
          </div>
          <span className="text-slate-300">·</span>
          <div className="flex items-center gap-1.5">
            <div
              className={`w-2 h-2 rounded-full ${
                sheetsConnected ? 'bg-emerald-500' : 'bg-slate-300'
              }`}
            />
            <span>Google Sheet: {sheetsConnected ? 'Ready' : 'Connect Account'}</span>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Studio Viewport */}
      <div className="mt-6 flex flex-col items-center justify-center min-h-[220px] bg-slate-50/70 rounded-xl border border-dashed border-slate-200 p-6 relative">
        {/* State: Idle */}
        {recordingState === 'idle' && (
          <div className="text-center">
            <button
              onClick={startRecording}
              disabled={isProcessing}
              className="w-20 h-20 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all mx-auto cursor-pointer"
              title="Start recording voice note"
            >
              <Mic className="w-8 h-8" />
            </button>
            <div className="mt-4 text-sm font-semibold text-slate-800">
              Tap to Record Voice Note
            </div>
            <div className="text-xs text-slate-500 mt-1">
              وائس میسج ریکارڈ کریں اور خودکار طور پر ڈرائیو اور شیٹ میں بھیجیں
            </div>
          </div>
        )}

        {/* State: Recording or Paused */}
        {(recordingState === 'recording' || recordingState === 'paused') && (
          <div className="w-full flex flex-col items-center">
            {/* Visualizer Canvas */}
            <canvas
              ref={canvasRef}
              width={360}
              height={70}
              className="w-full max-w-sm h-16 rounded-lg bg-white/60 border border-slate-200/80 mb-4"
            />

            <div className="text-3xl font-mono font-bold text-slate-900 tracking-wider">
              {formatTimer(seconds)}
            </div>

            <div className="flex items-center gap-2 mt-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  recordingState === 'recording' ? 'bg-red-500 animate-pulse' : 'bg-amber-500'
                }`}
              />
              <span className="text-xs font-medium text-slate-600">
                {recordingState === 'recording' ? 'Recording live audio...' : 'Recording paused'}
              </span>
            </div>

            {/* In-Recording Controls */}
            <div className="flex items-center gap-4 mt-6">
              <button
                onClick={discardRecording}
                className="p-3 text-slate-600 hover:text-red-600 hover:bg-white rounded-full border border-slate-200 transition-colors"
                title="Discard recording"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {recordingState === 'recording' ? (
                <button
                  onClick={pauseRecording}
                  className="p-3 text-slate-800 bg-white hover:bg-slate-100 rounded-full border border-slate-200 transition-colors shadow-2xs"
                  title="Pause recording"
                >
                  <Pause className="w-5 h-5" />
                </button>
              ) : (
                <button
                  onClick={resumeRecording}
                  className="p-3 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-full border border-emerald-200 transition-colors"
                  title="Resume recording"
                >
                  <Play className="w-5 h-5 ml-0.5" />
                </button>
              )}

              <button
                onClick={stopAndReview}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-full font-medium text-xs flex items-center gap-2 transition-all shadow-2xs"
                title="Stop and preview audio"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                Done & Review
              </button>
            </div>
          </div>
        )}

        {/* State: Review / Preview */}
        {recordingState === 'review' && audioUrl && (
          <div className="w-full max-w-md flex flex-col items-center">
            <audio
              ref={audioPlayerRef}
              src={audioUrl}
              onEnded={() => setIsPlayingPreview(false)}
              onTimeUpdate={(e) => setPlaybackTime(Math.floor((e.target as any).currentTime))}
            />

            <div className="w-full bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className="font-semibold text-slate-800">Preview Voice Note</span>
                <span className="font-mono">
                  {formatTimer(playbackTime)} / {formatTimer(seconds)}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlaybackPreview}
                  className="p-2.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg transition-colors"
                >
                  {isPlayingPreview ? (
                    <Pause className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4 ml-0.5" />
                  )}
                </button>

                <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 transition-all"
                    style={{
                      width: `${seconds > 0 ? (playbackTime / seconds) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-between w-full gap-3 mt-5">
              <button
                onClick={discardRecording}
                disabled={isProcessing}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Record Again
              </button>

              <button
                onClick={handleSave}
                disabled={isProcessing}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-2 shadow-2xs ml-auto"
              >
                {isProcessing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>{statusText || 'Syncing to Drive & Sheets...'}</span>
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-4 h-4" />
                    <span>Upload to Drive & Save to Sheet</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Auto-Transcribe & Integration Settings */}
      <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={autoTranscribe}
            onChange={(e) => setAutoTranscribe(e.target.checked)}
            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
          />
          <span className="flex items-center gap-1 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            Auto-Transcribe voice to text via Gemini (Urdu & English)
          </span>
        </label>

        <span className="text-slate-400">
          Audio is saved as WebM in Drive & cataloged with hyperlinked cell in Sheets
        </span>
      </div>
    </div>
  );
};
