import React, { useState } from 'react';
import { DriveFileInfo, WorkspaceFolder } from '../types';
import {
  HardDrive,
  ExternalLink,
  RefreshCw,
  Trash2,
  Music,
  FileSpreadsheet,
  File,
  Download,
} from 'lucide-react';
import { ConfirmationModal } from './ConfirmationModal';

interface DriveFolderViewerProps {
  folder: WorkspaceFolder | null;
  files: DriveFileInfo[];
  isLoading: boolean;
  onRefresh: () => Promise<void>;
  onDeleteFile: (fileId: string, fileName: string) => Promise<void>;
  isAuthenticated: boolean;
}

export const DriveFolderViewer: React.FC<DriveFolderViewerProps> = ({
  folder,
  files,
  isLoading,
  onRefresh,
  onDeleteFile,
  isAuthenticated,
}) => {
  const [selectedFileForDeletion, setSelectedFileForDeletion] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const formatFileSize = (bytesStr?: string) => {
    if (!bytesStr) return '—';
    const bytes = parseInt(bytesStr, 10);
    if (isNaN(bytes) || bytes === 0) return '—';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDate = (isoDate: string) => {
    if (!isoDate) return '—';
    try {
      const d = new Date(isoDate);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoDate;
    }
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.includes('audio')) {
      return <Music className="w-4 h-4 text-emerald-600" />;
    }
    if (mimeType.includes('spreadsheet')) {
      return <FileSpreadsheet className="w-4 h-4 text-emerald-700" />;
    }
    return <File className="w-4 h-4 text-slate-500" />;
  };

  const handleConfirmDelete = async () => {
    if (!selectedFileForDeletion) return;
    setIsDeleting(true);
    try {
      await onDeleteFile(selectedFileForDeletion.id, selectedFileForDeletion.name);
    } finally {
      setIsDeleting(false);
      setSelectedFileForDeletion(null);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
      {/* Header */}
      <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/70">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-blue-100 text-blue-800 rounded-lg">
              <HardDrive className="w-4 h-4" />
            </div>
            <h3 className="text-base font-semibold text-slate-900">
              {folder?.name || 'Google Drive Folder'}
            </h3>
            {folder?.webViewLink && (
              <a
                href={folder.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 hover:underline ml-2"
              >
                <span>Open in Google Drive</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Voice recordings are saved in your Google Drive folder with shareable links
          </p>
        </div>

        <button
          onClick={onRefresh}
          disabled={isLoading || !isAuthenticated}
          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors flex items-center gap-1.5 text-xs font-medium self-start md:self-auto"
          title="Refresh folder files"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Files List */}
      <div className="p-5">
        {!isAuthenticated ? (
          <div className="p-12 text-center text-slate-500">
            <HardDrive className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-700">Google Account Not Connected</p>
            <p className="text-xs text-slate-500 mt-1">
              Sign in with Google to view and manage audio recordings in Google Drive.
            </p>
          </div>
        ) : files.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <Music className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-700">No recordings stored in this folder yet</p>
            <p className="text-xs text-slate-500 mt-1">
              Any voice recordings made in the Voice Studio will appear here automatically.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map((file) => (
              <div
                key={file.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="p-2 rounded-lg bg-slate-100 shrink-0">
                      {getFileIcon(file.mimeType)}
                    </div>

                    <button
                      onClick={() => setSelectedFileForDeletion({ id: file.id, name: file.name })}
                      className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                      title="Delete recording from Google Drive"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h4 className="mt-3 text-sm font-semibold text-slate-900 truncate" title={file.name}>
                    {file.name}
                  </h4>

                  <div className="mt-1 flex items-center gap-2 text-xs text-slate-500 font-mono">
                    <span>{formatFileSize(file.size)}</span>
                    <span>·</span>
                    <span>{formatDate(file.createdTime)}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <a
                    href={file.webViewLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-medium text-emerald-700 hover:text-emerald-800 flex items-center gap-1 hover:underline"
                  >
                    <span>View in Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  {file.webContentLink && (
                    <a
                      href={file.webContentLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1"
                      title="Direct download"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Dialog for Deleting Drive File (Mandatory destructive operation confirmation) */}
      <ConfirmationModal
        isOpen={!!selectedFileForDeletion}
        title="Delete File from Google Drive?"
        description={`Are you sure you want to permanently delete "${selectedFileForDeletion?.name}" from your Google Drive? This cannot be undone.`}
        confirmLabel="Delete File"
        isDestructive={true}
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setSelectedFileForDeletion(null)}
      />
    </div>
  );
};
