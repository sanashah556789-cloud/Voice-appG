/**
 * Client service to communicate with server-side AI endpoints (/api/transcribe, /api/chat)
 */

export async function transcribeAudioBlob(blob: Blob): Promise<string> {
  // Convert blob to base64
  const arrayBuffer = await blob.arrayBuffer();
  const buffer = new Uint8Array(arrayBuffer);
  let binary = '';
  for (let i = 0; i < buffer.byteLength; i++) {
    binary += String.fromCharCode(buffer[i]);
  }
  const base64 = btoa(binary);

  const res = await fetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      audioBase64: base64,
      mimeType: blob.type || 'audio/webm',
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Transcription failed with code ${res.status}`);
  }

  const data = await res.json();
  return data.transcript || '';
}

export async function requestAiChatReply(
  message: string,
  history: Array<{ sender: 'user' | 'assistant'; text: string }> = []
): Promise<string> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message,
      history,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `AI Chat request failed with code ${res.status}`);
  }

  const data = await res.json();
  return data.reply || '';
}
