import { getAccessToken } from './auth';
import { SheetRowData, WorkspaceSpreadsheet } from '../types';

export const DEFAULT_SHEET_NAME = 'Voice & Chat Logs';
export const DEFAULT_SPREADSHEET_TITLE = 'Voice & Chat Master Log';

/**
 * Searches for or creates a dedicated Google Sheet with initialized column headers
 */
export async function findOrCreateLogSheet(
  folderId?: string,
  spreadsheetTitle = DEFAULT_SPREADSHEET_TITLE
): Promise<WorkspaceSpreadsheet> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated with Google');

  // Search if a spreadsheet with this title already exists in Drive
  let query = `name = '${spreadsheetTitle}' and mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false`;
  if (folderId) {
    query += ` and '${folderId}' in parents`;
  }
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,webViewLink)&pageSize=1`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  if (searchRes.ok) {
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      const file = searchData.files[0];
      return {
        id: file.id,
        title: file.name,
        webViewLink: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
        sheetName: DEFAULT_SHEET_NAME,
      };
    }
  }

  // Create new Spreadsheet with headers
  const createPayload = {
    properties: {
      title: spreadsheetTitle,
    },
    sheets: [
      {
        properties: {
          title: DEFAULT_SHEET_NAME,
          gridProperties: {
            frozenRowCount: 1,
            columnCount: 8,
          },
        },
        data: [
          {
            startRow: 0,
            startColumn: 0,
            rowData: [
              {
                values: [
                  { userEnteredValue: { stringValue: 'Log ID' } },
                  { userEnteredValue: { stringValue: 'Date & Time' } },
                  { userEnteredValue: { stringValue: 'Type' } },
                  { userEnteredValue: { stringValue: 'Sender' } },
                  { userEnteredValue: { stringValue: 'Message / Transcript' } },
                  { userEnteredValue: { stringValue: 'Google Drive Audio Link' } },
                  { userEnteredValue: { stringValue: 'Duration / Size' } },
                  { userEnteredValue: { stringValue: 'Sync Status' } },
                ],
              },
            ],
          },
        ],
      },
    ],
  };

  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(createPayload),
  });

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}));
    throw new Error(`Failed to create Google Sheet: ${err.error?.message || createRes.statusText}`);
  }

  const createdSheet = await createRes.json();
  const spreadsheetId = createdSheet.spreadsheetId;

  // Move newly created sheet into the dedicated folder if folderId is provided
  if (folderId) {
    try {
      await fetch(
        `https://www.googleapis.com/drive/v3/files/${spreadsheetId}?addParents=${folderId}&fields=id,parents`,
        {
          method: 'PATCH',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch {
      // Non-fatal if moving fails
    }
  }

  // Style header row (format background & bold font)
  try {
    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          {
            repeatCell: {
              range: {
                sheetId: 0,
                startRowIndex: 0,
                endRowIndex: 1,
                startColumnIndex: 0,
                endColumnIndex: 8,
              },
              cell: {
                userEnteredFormat: {
                  backgroundColor: { red: 0.94, green: 0.96, blue: 0.98 },
                  textFormat: { bold: true, fontSize: 10 },
                  horizontalAlignment: 'CENTER',
                },
              },
              fields: 'userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)',
            },
          },
        ],
      }),
    });
  } catch {
    // Non-fatal styling
  }

  return {
    id: spreadsheetId,
    title: spreadsheetTitle,
    webViewLink: createdSheet.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
    sheetName: DEFAULT_SHEET_NAME,
  };
}

/**
 * Appends a log entry to the Google Sheet
 */
export async function appendLogEntryToSheet(
  spreadsheetId: string,
  entry: SheetRowData,
  sheetName = DEFAULT_SHEET_NAME
): Promise<void> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated with Google');

  const formattedDriveCell = entry.driveLink.startsWith('http')
    ? `=HYPERLINK("${entry.driveLink}", "Open in Drive")`
    : entry.driveLink;

  const rowValues = [
    entry.id,
    entry.dateTime,
    entry.type,
    entry.sender,
    entry.messageOrTranscript,
    formattedDriveCell,
    entry.durationOrInfo,
    entry.status,
  ];

  const range = `'${sheetName}'!A:H`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(
    range
  )}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      values: [rowValues],
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Failed to append to Google Sheet: ${err.error?.message || res.statusText}`);
  }
}

/**
 * Reads logged rows from the Google Sheet
 */
export async function readRecentSheetRows(
  spreadsheetId: string,
  sheetName = DEFAULT_SHEET_NAME,
  maxRows = 100
): Promise<{ headers: string[]; rows: SheetRowData[] }> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated with Google');

  const range = `'${sheetName}'!A1:H${maxRows}`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Failed to read Google Sheet: ${err.error?.message || res.statusText}`);
  }

  const data = await res.json();
  const rawValues: string[][] = data.values || [];

  if (rawValues.length === 0) {
    return { headers: [], rows: [] };
  }

  const headers = rawValues[0] || [];
  const rows: SheetRowData[] = rawValues.slice(1).map((row, index) => {
    return {
      id: row[0] || `row-${index + 1}`,
      dateTime: row[1] || '',
      type: row[2] || '',
      sender: row[3] || '',
      messageOrTranscript: row[4] || '',
      driveLink: row[5] || '',
      durationOrInfo: row[6] || '',
      status: row[7] || '',
    };
  });

  return { headers, rows };
}

/**
 * Clears sheet data rows while preserving headers (requires user confirmation)
 */
export async function clearSheetDataRows(
  spreadsheetId: string,
  sheetName = DEFAULT_SHEET_NAME
): Promise<void> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated with Google');

  const range = `'${sheetName}'!A2:H500`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:clear`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({}),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Failed to clear sheet data: ${err.error?.message || res.statusText}`);
  }
}
