import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { AudioRecorder } from './components/AudioRecorder';
import { ChatTimeline } from './components/ChatTimeline';
import { SheetsTableViewer } from './components/SheetsTableViewer';
import { DriveFolderViewer } from './components/DriveFolderViewer';
import {
  initAuth,
  googleSignIn,
  logout,
  getAccessToken,
} from './services/auth';
import {
  findOrCreateAppFolder,
  uploadAudioToDrive,
  listDriveFolderFiles,
  deleteDriveFile,
} from './services/drive';
import {
  findOrCreateLogSheet,
  appendLogEntryToSheet,
  readRecentSheetRows,
  clearSheetDataRows,
  DEFAULT_SHEET_NAME,
} from './services/sheets';
import { transcribeAudioBlob, requestAiChatReply } from './services/ai';
import {
  UserProfile,
  VoiceMessageRecord,
  WorkspaceFolder,
  WorkspaceSpreadsheet,
  SheetRowData,
  DriveFileInfo,
} from './types';
import {
  HardDrive,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Mic,
  ArrowRight,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'chat' | 'sheets' | 'drive'>('studio');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Google Workspace Resources
  const [driveFolder, setDriveFolder] = useState<WorkspaceFolder | null>(null);
  const [logSheet, setLogSheet] = useState<WorkspaceSpreadsheet | null>(null);
  const [isInitializingWorkspace, setIsInitializingWorkspace] = useState(false);

  // Data & State
  const [messages, setMessages] = useState<VoiceMessageRecord[]>([]);
  const [sheetRows, setSheetRows] = useState<SheetRowData[]>([]);
  const [driveFiles, setDriveFiles] = useState<DriveFileInfo[]>([]);
  const [isLoadingSheets, setIsLoadingSheets] = useState(false);
  const [isLoadingDrive, setIsLoadingDrive] = useState(false);
  const [isProcessingAction, setIsProcessingAction] = useState(false);
  const [processingStatusText, setProcessingStatusText] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Initialize Workspace (Drive Folder & Google Sheet)
  const initializeWorkspace = useCallback(async () => {
    setIsInitializingWorkspace(true);
    try {
      // 1. Find or create Drive folder
      const folder = await findOrCreateAppFolder('Voice & Chat App');
      setDriveFolder(folder);

      // 2. Find or create Google Sheet inside that folder
      const sheet = await findOrCreateLogSheet(folder.id, 'Voice & Chat Master Log');
      setLogSheet(sheet);

      // 3. Load initial rows and files
      loadSheetRows(sheet.id, sheet.sheetName);
      loadDriveFiles(folder.id);
    } catch (err: any) {
      console.error('Workspace init error:', err);
      showToast(`Workspace init warning: ${err.message || 'Check permissions'}`);
    } finally {
      setIsInitializingWorkspace(false);
    }
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = initAuth(
      (firebaseUser, _token) => {
        setUser({
          uid: firebaseUser.uid,
          displayName: firebaseUser.displayName,
          email: firebaseUser.email,
          photoURL: firebaseUser.photoURL,
        });
        setAuthError(null);
        initializeWorkspace();
      },
      () => {
        setUser(null);
        setDriveFolder(null);
        setLogSheet(null);
      }
    );

    return () => unsubscribe();
  }, [initializeWorkspace]);

  const handleSignIn = async () => {
    setIsAuthenticating(true);
    setAuthError(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser({
          uid: res.user.uid,
          displayName: res.user.displayName,
          email: res.user.email,
          photoURL: res.user.photoURL,
        });
        showToast('Connected to Google Account successfully');
        await initializeWorkspace();
      }
    } catch (err: any) {
      console.error('Sign in failed:', err);
      setAuthError(err.message || 'Authentication failed. Please try again.');
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    setUser(null);
    setDriveFolder(null);
    setLogSheet(null);
    setSheetRows([]);
    setDriveFiles([]);
    showToast('Signed out from Google Account');
  };

  // Load Sheet Rows
  const loadSheetRows = async (spreadsheetId?: string, sheetName?: string) => {
    const sId = spreadsheetId || logSheet?.id;
    if (!sId) return;
    setIsLoadingSheets(true);
    try {
      const data = await readRecentSheetRows(sId, sheetName || DEFAULT_SHEET_NAME);
      setSheetRows(data.rows);
    } catch (err: any) {
      console.error('Failed to load sheet rows:', err);
    } finally {
      setIsLoadingSheets(false);
    }
  };

  // Load Drive Files
  const loadDriveFiles = async (folderId?: string) => {
    const fId = folderId || driveFolder?.id;
    if (!fId) return;
    setIsLoadingDrive(true);
    try {
      const files = await listDriveFolderFiles(fId);
      setDriveFiles(files);
    } catch (err: any) {
      console.error('Failed to load Drive files:', err);
    } finally {
      setIsLoadingDrive(false);
    }
  };

  // Handle Recording Save
  const handleSaveVoiceNote = async (
    audioBlob: Blob,
    duration: number,
    autoTranscribe: boolean
  ) => {
    const token = await getAccessToken();
    if (!token) {
      showToast('Please sign in with Google to upload recordings');
      handleSignIn();
      return;
    }

    setIsProcessingAction(true);
    const messageId = `rec-${Date.now()}`;
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const localAudioUrl = URL.createObjectURL(audioBlob);

    // Initial placeholder message in state
    const tempMsg: VoiceMessageRecord = {
      id: messageId,
      timestamp: now.toISOString(),
      formattedTime,
      type: 'voice',
      sender: 'user',
      content: autoTranscribe ? 'Transcribing voice audio...' : 'Voice recording note',
      audioBlob,
      audioUrl: localAudioUrl,
      audioDuration: duration,
      syncStatus: 'uploading_drive',
    };
    setMessages((prev) => [...prev, tempMsg]);

    try {
      // 1. Transcribe audio if requested
      let transcript = '';
      if (autoTranscribe) {
        setProcessingStatusText('Transcribing audio via Gemini...');
        try {
          transcript = await transcribeAudioBlob(audioBlob);
        } catch (e: any) {
          console.warn('Transcription failed:', e);
          transcript = '(Voice note uploaded without transcription)';
        }
      } else {
        transcript = `Voice recording note (${duration}s)`;
      }

      // Update message content with transcript
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, content: transcript } : m))
      );

      // 2. Upload audio file to Google Drive
      setProcessingStatusText('Uploading audio file to Google Drive...');
      const dateStamp = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const fileName = `Voice_Note_${dateStamp}.webm`;
      const uploadedFile = await uploadAudioToDrive(
        audioBlob,
        fileName,
        driveFolder?.id || undefined
      );

      // 3. Append row to Google Sheet
      setProcessingStatusText('Appending record to Google Sheet...');
      if (logSheet) {
        const rowData: SheetRowData = {
          id: messageId,
          dateTime: now.toLocaleString(),
          type: 'Voice Memo',
          sender: user?.displayName || 'User',
          messageOrTranscript: transcript,
          driveLink: uploadedFile.webViewLink,
          durationOrInfo: `${duration}s (${Math.round(audioBlob.size / 1024)} KB)`,
          status: 'Synced',
        };

        await appendLogEntryToSheet(logSheet.id, rowData, logSheet.sheetName);
      }

      // Update message in state to synced
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId
            ? {
                ...m,
                content: transcript,
                driveFileId: uploadedFile.id,
                driveFileName: uploadedFile.name,
                driveViewLink: uploadedFile.webViewLink,
                driveDownloadLink: uploadedFile.webContentLink,
                syncStatus: 'synced',
              }
            : m
        )
      );

      showToast('Voice note uploaded to Drive & recorded in Sheet!');

      // Refresh sheets & drive
      if (logSheet) loadSheetRows(logSheet.id, logSheet.sheetName);
      if (driveFolder) loadDriveFiles(driveFolder.id);

      // 4. Optional AI response if transcribed and informative
      if (autoTranscribe && transcript && transcript.length > 3) {
        setProcessingStatusText('Generating AI response...');
        try {
          const aiReply = await requestAiChatReply(transcript, [
            { sender: 'user', text: transcript },
          ]);

          if (aiReply) {
            const aiMsgId = `ai-${Date.now()}`;
            const aiNow = new Date();
            const aiMsg: VoiceMessageRecord = {
              id: aiMsgId,
              timestamp: aiNow.toISOString(),
              formattedTime: aiNow.toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              }),
              type: 'text',
              sender: 'assistant',
              content: aiReply,
              syncStatus: 'synced',
            };

            setMessages((prev) => [...prev, aiMsg]);

            // Also log AI reply to Google Sheet
            if (logSheet) {
              await appendLogEntryToSheet(
                logSheet.id,
                {
                  id: aiMsgId,
                  dateTime: aiNow.toLocaleString(),
                  type: 'AI Assistant',
                  sender: 'AI Assistant',
                  messageOrTranscript: aiReply,
                  driveLink: 'N/A',
                  durationOrInfo: 'Text Response',
                  status: 'Synced',
                },
                logSheet.sheetName
              );
              loadSheetRows(logSheet.id, logSheet.sheetName);
            }
          }
        } catch (aiErr) {
          console.warn('AI reply failed:', aiErr);
        }
      }
    } catch (err: any) {
      console.error('Error saving voice note:', err);
      showToast(`Error: ${err.message || 'Failed to save voice note'}`);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId
            ? { ...m, syncStatus: 'error', errorMessage: err.message }
            : m
        )
      );
    } finally {
      setIsProcessingAction(false);
      setProcessingStatusText('');
    }
  };

  // Handle Text Message Send
  const handleSendTextMessage = async (text: string, enableAiReply: boolean) => {
    const token = await getAccessToken();
    if (!token) {
      showToast('Please sign in with Google to send and log messages');
      handleSignIn();
      return;
    }

    setIsProcessingAction(true);
    const messageId = `msg-${Date.now()}`;
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const userMsg: VoiceMessageRecord = {
      id: messageId,
      timestamp: now.toISOString(),
      formattedTime,
      type: 'text',
      sender: 'user',
      content: text,
      syncStatus: 'synced',
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      // 1. Log to Google Sheet
      if (logSheet) {
        await appendLogEntryToSheet(
          logSheet.id,
          {
            id: messageId,
            dateTime: now.toLocaleString(),
            type: 'Text Chat',
            sender: user?.displayName || 'User',
            messageOrTranscript: text,
            driveLink: 'N/A',
            durationOrInfo: 'Text Message',
            status: 'Synced',
          },
          logSheet.sheetName
        );
        loadSheetRows(logSheet.id, logSheet.sheetName);
      }

      showToast('Message logged to Google Sheet!');

      // 2. AI Assistant Response if enabled
      if (enableAiReply) {
        const history = messages.slice(-5).map((m) => ({
          sender: m.sender,
          text: m.content,
        }));

        const aiReply = await requestAiChatReply(text, history);
        if (aiReply) {
          const aiMsgId = `ai-${Date.now()}`;
          const aiNow = new Date();
          const aiMsg: VoiceMessageRecord = {
            id: aiMsgId,
            timestamp: aiNow.toISOString(),
            formattedTime: aiNow.toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            }),
            type: 'text',
            sender: 'assistant',
            content: aiReply,
            syncStatus: 'synced',
          };

          setMessages((prev) => [...prev, aiMsg]);

          if (logSheet) {
            await appendLogEntryToSheet(
              logSheet.id,
              {
                id: aiMsgId,
                dateTime: aiNow.toLocaleString(),
                type: 'AI Assistant',
                sender: 'AI Assistant',
                messageOrTranscript: aiReply,
                driveLink: 'N/A',
                durationOrInfo: 'Text Response',
                status: 'Synced',
              },
              logSheet.sheetName
            );
            loadSheetRows(logSheet.id, logSheet.sheetName);
          }
        }
      }
    } catch (err: any) {
      console.error('Error sending message:', err);
      showToast(`Error: ${err.message || 'Failed to process message'}`);
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Clear Sheet Action
  const handleClearSheet = async () => {
    if (!logSheet) return;
    try {
      await clearSheetDataRows(logSheet.id, logSheet.sheetName);
      showToast('Google Sheet rows cleared successfully');
      loadSheetRows(logSheet.id, logSheet.sheetName);
    } catch (err: any) {
      showToast(`Error: ${err.message || 'Failed to clear sheet'}`);
    }
  };

  // Delete Drive File Action
  const handleDeleteDriveFile = async (fileId: string, fileName: string) => {
    try {
      await deleteDriveFile(fileId);
      showToast(`File "${fileName}" deleted from Google Drive`);
      if (driveFolder) loadDriveFiles(driveFolder.id);
    } catch (err: any) {
      showToast(`Error: ${err.message || 'Failed to delete file'}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        isAuthenticating={isAuthenticating}
      />

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-lg text-xs font-medium flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Workspace Connection Hero Bar */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">
                Google Drive & Google Sheets Voice Hub
              </h1>
              <p className="text-xs text-slate-600 mt-1">
                وائس اور چیٹ ایپ — وائس گوگل ڈرائیو میں محفوظ ہوتی ہے اور اس کا لنک مع میسج گوگل شیٹ
                میں درج ہوتا ہے۔
              </p>
            </div>

            {/* Quick Status Pillows (Unboxed Text with dots) */}
            <div className="flex flex-wrap items-center gap-4 text-xs">
              {driveFolder ? (
                <a
                  href={driveFolder.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-emerald-700 hover:text-emerald-800 font-medium hover:underline"
                >
                  <HardDrive className="w-4 h-4 text-emerald-600" />
                  <span>Drive: {driveFolder.name}</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              ) : (
                <div className="flex items-center gap-1.5 text-slate-500">
                  <HardDrive className="w-4 h-4 text-slate-400" />
                  <span>Drive: {user ? 'Connecting...' : 'Not Connected'}</span>
                </div>
              )}

              <span className="text-slate-300">·</span>

              {logSheet ? (
                <a
                  href={logSheet.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-blue-700 hover:text-blue-800 font-medium hover:underline"
                >
                  <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                  <span>Sheet: {logSheet.title}</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              ) : (
                <div className="flex items-center gap-1.5 text-slate-500">
                  <FileSpreadsheet className="w-4 h-4 text-slate-400" />
                  <span>Sheet: {user ? 'Connecting...' : 'Not Connected'}</span>
                </div>
              )}
            </div>
          </div>

          {!user && (
            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-blue-50/50 p-3.5 rounded-lg border-blue-100">
              <div className="text-xs text-blue-900">
                <span className="font-semibold">Sign in required:</span> Please connect your Google
                account to grant permissions for saving audio to Google Drive and logging rows to Google
                Sheets.
              </div>
              <button
                onClick={handleSignIn}
                disabled={isAuthenticating}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto shrink-0 flex items-center gap-1.5"
              >
                <span>Connect Google Workspace</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {authError && (
            <div className="mt-3 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{authError}</span>
            </div>
          )}
        </div>

        {/* Tab 1: Combined Studio & Chat View */}
        {activeTab === 'studio' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-6 space-y-6">
              <AudioRecorder
                onSaveVoiceNote={handleSaveVoiceNote}
                isProcessing={isProcessingAction}
                statusText={processingStatusText}
                driveConnected={!!driveFolder}
                sheetsConnected={!!logSheet}
              />

              {/* Quick Workspace Stats */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                  Workspace Synchronization Status
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <div className="text-xs text-slate-500">Google Drive Files</div>
                    <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                      {driveFiles.length}
                    </div>
                    {driveFolder?.webViewLink && (
                      <a
                        href={driveFolder.webViewLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1 mt-1 font-medium"
                      >
                        <span>Open Folder</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <div className="text-xs text-slate-500">Google Sheet Rows</div>
                    <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                      {sheetRows.length}
                    </div>
                    {logSheet?.webViewLink && (
                      <a
                        href={logSheet.webViewLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-blue-700 hover:underline flex items-center gap-1 mt-1 font-medium"
                      >
                        <span>Open Spreadsheet</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <ChatTimeline
                messages={messages}
                onSendTextMessage={handleSendTextMessage}
                isProcessing={isProcessingAction}
                driveFolderName={driveFolder?.name || 'Voice & Chat App'}
                sheetTitle={logSheet?.title || 'Voice & Chat Master Log'}
              />
            </div>
          </div>
        )}

        {/* Tab 2: Full Chat Timeline */}
        {activeTab === 'chat' && (
          <div className="max-w-4xl mx-auto">
            <ChatTimeline
              messages={messages}
              onSendTextMessage={handleSendTextMessage}
              isProcessing={isProcessingAction}
              driveFolderName={driveFolder?.name || 'Voice & Chat App'}
              sheetTitle={logSheet?.title || 'Voice & Chat Master Log'}
            />
          </div>
        )}

        {/* Tab 3: Google Sheets Live Inspector */}
        {activeTab === 'sheets' && (
          <SheetsTableViewer
            spreadsheet={logSheet}
            rows={sheetRows}
            isLoading={isLoadingSheets}
            onRefresh={() => loadSheetRows()}
            onClearSheet={handleClearSheet}
            isAuthenticated={!!user}
          />
        )}

        {/* Tab 4: Google Drive Folder Files */}
        {activeTab === 'drive' && (
          <DriveFolderViewer
            folder={driveFolder}
            files={driveFiles}
            isLoading={isLoadingDrive}
            onRefresh={() => loadDriveFiles()}
            onDeleteFile={handleDeleteDriveFile}
            isAuthenticated={!!user}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>VoiceDrive Hub · Integrated with Google Drive v3 & Google Sheets v4</span>
          <span>Voice recordings saved with Drive hyperlinks and speech transcription</span>
        </div>
      </footer>
    </div>
  );
}
