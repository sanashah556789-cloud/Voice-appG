import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// High body limit for base64 audio data
app.use(express.json({ limit: '64mb' }));

// Initialize Google GenAI if key is available
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API: Transcribe Audio
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'Missing audio data' });
    }

    if (!ai) {
      return res.json({
        transcript: 'Voice recording received (Gemini API key not configured for auto-transcription)',
      });
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType || 'audio/webm',
        data: audioBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          audioPart,
          {
            text: 'Transcribe this voice audio accurately. If the speaker speaks in Urdu, transcribe in clear Urdu script. If in English, transcribe in English. Return only the verbatim transcription without commentary or quotes.',
          },
        ],
      },
    });

    const transcript = response.text?.trim() || '';
    return res.json({ transcript: transcript || '(Inaudible voice note)' });
  } catch (err: any) {
    console.error('Transcription error:', err);
    return res.status(500).json({
      error: 'Failed to transcribe audio',
      details: err?.message || 'Unknown error',
    });
  }
});

// API: Chat Assistant
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!ai) {
      return res.json({
        reply: `Received your message: "${message}". (To enable AI replies, configure GEMINI_API_KEY in Secrets).`,
      });
    }

    // Format contents
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const h of history) {
        contents.push({
          role: h.sender === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction:
          'You are a helpful, professional AI assistant built into the Google Drive and Google Sheets Voice & Chat Hub. You assist users in both Urdu (اردو) and English seamlessly based on their language. Respond concisely and constructively.',
      },
    });

    const reply = response.text?.trim() || 'No response generated.';
    return res.json({ reply });
  } catch (err: any) {
    console.error('Chat error:', err);
    return res.status(500).json({
      error: 'Failed to generate chat response',
      details: err?.message || 'Unknown error',
    });
  }
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
